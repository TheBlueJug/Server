﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Threading;
namespace Server_new
{
    internal class Program
    {
        static Dictionary<Socket, string> clientSockets = new Dictionary<Socket, string>();
        static void Main(string[] args)
        {
            // Создаем сокет для прослушивания входящих соединений
            Socket serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint serverEndPoint = new IPEndPoint(IPAddress.Any, 8080);
            serverSocket.Bind(serverEndPoint);
            serverSocket.Listen(10);

            Console.WriteLine("Сервер запущен, ожидание подключений...");

            while (true)
            {
                // Ожидаем подключения нового клиента
                Socket clientSocket = serverSocket.Accept();
                


                // получаем никнейм клиента
                byte[] nickname_buffer = new byte[1024];
                int nickname_received = clientSocket.Receive(nickname_buffer);
                string nickname = Encoding.UTF8.GetString(nickname_buffer, 0, nickname_received);

                // Добавляем клиента в список подключенных
                clientSockets[clientSocket] = nickname + "(" + clientSocket.RemoteEndPoint.ToString() + ")";


                Console.WriteLine($"Новое подключение: {clientSockets[clientSocket]}");

                // Запускаем новый поток для обработки сообщений от клиента
                Thread thread = new Thread(() => HandleClient(clientSocket));
                thread.Start();
            }

        }

        static void HandleClient(Socket clientSocket)
        {
            byte[] buffer = new byte[1024];
            int bytesReceived;

            while (true)
            {
                try
                {
                    // Получаем сообщение от клиента
                    bytesReceived = clientSocket.Receive(buffer);
                    if (bytesReceived == 0)
                        break;

                    // Распечатываем сообщение в консоль
                    string message = clientSockets[clientSocket] + ":" + " " + Encoding.UTF8.GetString(buffer, 0, bytesReceived);
                    Console.WriteLine(message);

                    // Отправляем сообщение всем подключенным клиентам
                    BroadcastMessage(message);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при обработке клиента: {ex.Message}");
                    RemoveClient(clientSocket);
                    break;
                }
            }

            // Закрываем соединение с клиентом
            RemoveClient(clientSocket);
        }

        static void BroadcastMessage(string message)
        {
            byte[] data = Encoding.UTF8.GetBytes(message);
            foreach (var pair in clientSockets)
            {
                try
                {
                    pair.Key.Send(data);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при отправке сообщения клиенту {pair.Value}: {ex.Message}");
                    RemoveClient(pair.Key);
                }
            }
        }
        
        static void RemoveClient(Socket clientSocket)
        {
            if (clientSockets.ContainsKey(clientSocket))
            {
                Console.WriteLine($"Отключен клиент: {clientSockets[clientSocket]}");
                clientSockets.Remove(clientSocket);
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();
            }
        } 

    }
}
